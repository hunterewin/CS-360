package com.mobile2app.models;

public class Permission {
    private int isGranted;

    public Permission(){

    }

    public Permission(int isGranted) {
        this.isGranted = isGranted;
    }

    public int isGranted() {
        return isGranted;
    }
}
