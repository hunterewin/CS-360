package com.mobile2app.activities;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.mobile2app.classes.AlarmReceiver;
import com.mobile2app.R;
import com.mobile2app.adapters.WeightEntryAdapter;
import com.mobile2app.models.WeightEntry;
import com.mobile2app.storage.SharePreferenceManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private WeightEntryAdapter adapter;
    private List<WeightEntry> weightList = new ArrayList<>();
  private Button logout_button;
  private FloatingActionButton add_button;
    public static final String NOTIFICATION_CHANNEL_ID = "10001" ;
    private final static String default_notification_channel_id = "default" ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        logout_button=findViewById(R.id.logout_button);
        add_button = findViewById(R.id.add_button);

        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,CreateActivity.class);
                startActivity(intent);
            }
        });


        logout_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logoutUser();
            }
        });

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        getData();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if(!SharePreferenceManager.getInstance(this).isPermission()){
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setMessage("NEW LIFE would like to show Notifications. Please Grant or Deny Permission to continue.")
                    .setPositiveButton("Allow", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                           SharePreferenceManager.getInstance(MainActivity.this).savePermissionStatus(1);
                            scheduleNotification(getNotification( "Congratulations! You will receive instant notifications from this Application." ) , 5000 );
                        }
                    })
                    .setNegativeButton("Deny", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            SharePreferenceManager.getInstance(MainActivity.this).savePermissionStatus(0);
                        }
                    });
            builder.show();
        }
    }

    private void logoutUser() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setMessage("Are you sure you want to logout from this App?")
                .setPositiveButton("Logout", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        SharePreferenceManager.getInstance(MainActivity.this).logout();
                       Intent intent = new Intent(MainActivity.this,LoginActivity.class);
                       startActivity(intent);
                       finish();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
        builder.show();

    }

    private void scheduleNotification (Notification notification , int delay) {
        Intent notificationIntent = new Intent( this, AlarmReceiver. class ) ;
        notificationIntent.putExtra(AlarmReceiver. NOTIFICATION_ID , 1 ) ;
        notificationIntent.putExtra(AlarmReceiver. NOTIFICATION , notification) ;
        PendingIntent pendingIntent = PendingIntent. getBroadcast ( this, 0 , notificationIntent , PendingIntent. FLAG_UPDATE_CURRENT ) ;
        long futureInMillis = SystemClock. elapsedRealtime () + delay ;
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context. ALARM_SERVICE ) ;
        assert alarmManager != null;
        alarmManager.set(AlarmManager. ELAPSED_REALTIME_WAKEUP , futureInMillis , pendingIntent) ;
    }
    private Notification getNotification (String content) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder( this, default_notification_channel_id ) ;
        builder.setContentTitle( "New Life Notification" ) ;
        builder.setContentText(content) ;
        builder.setSmallIcon(R.drawable. ic_launcher_foreground ) ;
        builder.setAutoCancel( true ) ;
        builder.setChannelId( NOTIFICATION_CHANNEL_ID ) ;
        return builder.build() ;
    }


    private void getData(){

        Random random = new Random();
        for(int i=0;i<5;i++){
            JSONObject weight = new JSONObject();
            try {
                weight.put("id", random.nextInt(10));
                weight.put("weightGained", random.nextInt(20));
                weight.put("weightLost", random.nextInt(8));
                weight.put("weightGoal", random.nextInt(50));
                weight.put("date", "5/5/2020");

                Gson gson = new Gson();
                weightList.add(gson.fromJson(weight.toString(), WeightEntry.class));



            } catch (JSONException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    adapter = new WeightEntryAdapter(MainActivity.this, weightList);

                    recyclerView.setAdapter(adapter);
                }
            });

        }

    }



}

//Hunterewin