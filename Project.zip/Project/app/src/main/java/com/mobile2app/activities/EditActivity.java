package com.mobile2app.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.mobile2app.R;

public class EditActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);
    }
}