package com.mobile2app.storage;

import android.content.Context;
import android.content.SharedPreferences;

public class SharePreferenceManager {
    private static final String SHARED_PREF_NAME = "my_shared_preff";
    private static SharePreferenceManager mInstance;
    private Context mCtx;

    private SharePreferenceManager(Context mCtx) {
        this.mCtx = mCtx;
    }

    public static synchronized SharePreferenceManager getInstance(Context mCtx) {
        if (mInstance == null) {
            mInstance = new SharePreferenceManager(mCtx);
        }

        return mInstance;
    }

    public void savePermissionStatus(int status) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("isGranted", String.valueOf(status));
        editor.apply();
    }

    public boolean isPermission() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        if (Integer.parseInt(sharedPreferences.getString("isGranted", "0")) != 0)
            return true;

        return false;

    }

    public void logout() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
    }
}
